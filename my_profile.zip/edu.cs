
head{
padding-bottom: .75em;
border-bottom: 3px solid black;
margin-bottom: 0;}
body{
font-size: 100%;
margin-left:2em;
margin-right:2em;
}

h1 { color : blue;}
body { background-color #FFFFCC; }
h2 {
color : blue;
text-shadow: -2px -2px 4px red; }
p
{font-size: 100%;
}




